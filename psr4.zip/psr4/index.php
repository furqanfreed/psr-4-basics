<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

use Codecourse\Repositories\UserRepository as UserRepository;
use Codecourse\DB\DbConnection as DbConnection;

require_once 'app/start.php';


$user = new UserRepository();

echo "<br>";

$db = new DbConnection();
