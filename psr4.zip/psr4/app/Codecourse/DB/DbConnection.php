<?php

namespace Codecourse\DB;

class DBConnection
{
	
	public function __construct()
	{
		echo "DB Class";
	}
}
