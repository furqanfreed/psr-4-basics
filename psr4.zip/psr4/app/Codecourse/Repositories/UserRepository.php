<?php 

namespace Codecourse\Repositories;

class UserRepository
{
	public function __construct()
	{
		echo 'Hello.';
	}
}
